import json
import unittest
from pathlib import Path

from lpd.storage import PlaceStore, atomic_write_text
from tests.helpers import good, temp_store


class StorageTests(unittest.TestCase):
    def test_missing_file_creates_template(self):
        store, d = temp_store()
        self.assertTrue((d / "places.json").exists())
        self.assertTrue(store.notices)
        self.assertEqual(store.places, [])

    def test_persistence_across_restart(self):
        store, d = temp_store()
        place, errs = store.add_raw(good())
        self.assertEqual(errs, [])
        reloaded = PlaceStore(d / "places.json").load()
        self.assertEqual(len(reloaded.places), 1)
        self.assertEqual(reloaded.places[0].name, "Test Cafe")
        self.assertEqual(reloaded.notices, [])

    def test_corrupt_json_is_backed_up_and_reset(self):
        d = temp_store()[1]
        path = d / "places.json"
        path.write_text("{ this is not json", encoding="utf-8")
        store = PlaceStore(path).load()
        self.assertEqual(store.places, [])
        self.assertTrue(any("corrupt" in n.lower() for n in store.notices))
        self.assertEqual(len(list(d.glob("places.corrupt-*.json"))), 1)
        json.loads(path.read_text(encoding="utf-8"))  # file is valid again

    def test_wrong_structure_is_quarantined(self):
        d = temp_store()[1]
        path = d / "places.json"
        path.write_text('{"places": "oops"}', encoding="utf-8")
        self.assertEqual(PlaceStore(path).load().places, [])

    def test_bad_records_skipped_good_kept(self):
        d = temp_store()[1]
        path = d / "places.json"
        path.write_text(json.dumps({"places": [good(), good(name="", address="x y z"), "junk", good(name="Two", address="B Road")]}))
        store = PlaceStore(path).load()
        self.assertEqual([p.name for p in store.places], ["Test Cafe", "Two"])
        self.assertEqual(len(store.notices), 2)

    def test_duplicate_ids_repaired(self):
        d = temp_store()[1]
        path = d / "places.json"
        a, b = good(id=1), good(id=1, name="Other", address="Z Road")
        path.write_text(json.dumps([a, b]))
        ids = [p.id for p in PlaceStore(path).load().places]
        self.assertEqual(len(set(ids)), 2)

    def test_duplicate_rejected(self):
        store, _ = temp_store(1)
        _, errs = store.add_raw(good(name="PLACE 0", address="0 road"))
        self.assertTrue(errs and errs[0].startswith("duplicate"))

    def test_update_and_delete(self):
        store, _ = temp_store(2)
        pid = store.places[0].id
        place, errs = store.update_raw(pid, {"rating": "1.5"})
        self.assertEqual((errs, place.rating), ([], 1.5))
        _, errs = store.update_raw(pid, {"rating": "11"})
        self.assertTrue(errs)
        self.assertEqual(store.get(pid).rating, 1.5)  # unchanged after failed update
        self.assertTrue(store.delete(pid))
        self.assertFalse(store.delete(pid))

    def test_atomic_write_leaves_no_temp_files(self):
        d = temp_store()[1]
        atomic_write_text(d / "x.txt", "hello")
        self.assertEqual((d / "x.txt").read_text(), "hello")
        self.assertEqual(list(d.glob("*.tmp")), [])

    def test_atomic_write_failure_keeps_original(self):
        d = temp_store()[1]
        target = d / "keep.txt"
        target.write_text("original")
        with self.assertRaises(Exception):
            atomic_write_text(target, 12345)  # not a str -> write fails mid-way
        self.assertEqual(target.read_text(), "original")
        self.assertEqual(list(d.glob("*.tmp")), [])

    def test_csv_roundtrip_header(self):
        store, d = temp_store(2)
        store.save_csv(d / "out.csv")
        first = Path(d / "out.csv").read_text().splitlines()[0]
        self.assertTrue(first.startswith("id,name,category"))


if __name__ == "__main__":
    unittest.main()
