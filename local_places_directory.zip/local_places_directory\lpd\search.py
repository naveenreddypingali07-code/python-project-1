"""Core search engine: keyword relevance ranking + category/rating/distance filters."""
from __future__ import annotations

SORTS = ("relevance", "rating", "distance", "name", "price")


def _score(place, tokens) -> int:
    """Return relevance score, or 0 if any token fails to match (AND semantics)."""
    name = place.name.lower()
    cat = place.category.lower()
    addr = place.address.lower()
    tags = [t.lower() for t in place.tags]
    total = 0
    for tok in tokens:
        s = 0
        if tok in name:
            s += 5 if name.startswith(tok) else 3
        if any(tok in t for t in tags):
            s += 2
        if tok in cat:
            s += 2
        if tok in addr:
            s += 1
        if s == 0:
            return 0
        total += s
    return total


def search(places, keyword="", category=None, min_rating=None, max_distance=None,
           status=None, max_price=None, sort="relevance", limit=None):
    if sort not in SORTS:
        raise ValueError(f"sort must be one of {SORTS}")
    tokens = [t for t in keyword.lower().split() if t]
    results = []
    for p in places:
        if category and p.category.lower() != category.lower():
            continue
        if min_rating is not None and p.rating < min_rating:
            continue
        if max_distance is not None and p.distance_km > max_distance:
            continue
        if status and p.status != status:
            continue
        if max_price is not None and p.price_level > max_price:
            continue
        score = _score(p, tokens) if tokens else 1
        if score:
            results.append((score, p))
    keys = {
        "relevance": lambda sp: (-sp[0], -sp[1].rating, sp[1].distance_km),
        "rating": lambda sp: (-sp[1].rating, sp[1].distance_km),
        "distance": lambda sp: (sp[1].distance_km, -sp[1].rating),
        "name": lambda sp: sp[1].name.lower(),
        "price": lambda sp: (sp[1].price_level, -sp[1].rating),
    }
    results.sort(key=keys[sort])
    out = [p for _, p in results]
    return out[:limit] if limit else out
