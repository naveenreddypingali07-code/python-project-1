# Local Places Directory (Project #57 - Everyday Innovators)

A Python 3.10+ application to **search a curated JSON directory of nearby useful places**, with a
menu-driven terminal interface (the primary deliverable) and an optional website that runs on the
same core. **Zero third-party dependencies** (Matplotlib is optional, only for a PNG chart).

## Quick start

```bash
python main.py            # interactive terminal menu
python main.py web        # website at http://127.0.0.1:8000  (opens your browser)
python -m unittest discover -s tests -t .     # run the 48 automated tests
```
Windows: use `py -3` instead of `python` if needed.

One-shot commands (good for scripts / demo):
```bash
python main.py search cafe --min-rating 4 --sort distance
python main.py summary          # executive summary
python main.py warnings         # threshold warnings
python main.py export           # Markdown + audit log + 2 CSV reports -> exports/
python main.py import data/legacy_sample.csv   # bulk import with row-by-row error log
```

## Features vs. the brief

| Brief requirement | Where |
|---|---|
| Interactive terminal interface (menu, ANSI colours, pagination) | `lpd/cli.py` |
| Defensive input validation (type, range, regex, control chars) | `lpd/validation.py` - used by CLI, CSV import and web API |
| Core logic: search engine (AND-keyword relevance ranking + filters + sorting) | `lpd/search.py` |
| Local persistence (JSON primary, CSV export), survives restarts | `lpd/storage.py` |
| Corrupt/missing file recovery (FileNotFoundError, JSONDecodeError -> backup + clean template) | `PlaceStore.load` |
| Atomic file I/O (temp file + fsync + `os.replace`) | `atomic_write_text` |
| Keyword and category search | menu 2 / `search` command / website |
| Executive summary (totals, averages, status indicators, trends) | `lpd/analytics.py` |
| Stretch: Markdown, audit log and CSV export | `lpd/export.py` |
| Stretch: threshold warnings (stale, low rating, far, duplicate, closed) | `analytics.find_warnings` |
| Stretch: GUI enhancement | website (`lpd/web.py`, `lpd/static/index.html`) |
| Stretch: bulk CSV import with row-by-row error log | `lpd/importer.py` |
| Matplotlib charts (optional) + ASCII charts always | `lpd/charts.py` |
| 30-50 realistic sample records incl. edge cases (CSV + JSON) | `data/` (44 records) |

## Project layout

```
main.py                entry point
lpd/                   models, validation, storage, search, analytics, export, importer, charts, cli, web
lpd/static/index.html  website UI
data/                  places.json (44 records), places.csv, legacy_sample.csv (deliberately messy)
tests/                 48 unit/integration tests (unittest)
scripts/seed_data.py   regenerates the sample data
docs/                  architecture, demo script, evaluation checklist
exports/               generated reports
```

## Design notes
- **Separation of concerns**: UI layers (CLI, web) never touch files or rules directly; they call
  `PlaceStore`, `validate_record`, `search`, `summarize`.
- **Single validation path**: whatever the entry point, every record goes through `validate_record`.
- **Safe web**: server-side validation, 20 KB body limit, security headers, UI built with
  `textContent` only (no `innerHTML`), binds to localhost by default.
- **Data safety**: a failed write never corrupts the file; a corrupt file is copied to
  `places.corrupt-<timestamp>.json` before being reset.

Sample data is fictional but modelled on a campus neighbourhood.
