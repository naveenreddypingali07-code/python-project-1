"""Multi-format report export: Markdown, plain-text audit log, standardized CSV."""
from __future__ import annotations

import csv
import io
from datetime import datetime
from pathlib import Path

from .analytics import find_warnings, summarize
from .storage import atomic_write_text, places_to_csv


def render_markdown(places, today=None) -> str:
    s = summarize(places, today)
    w = find_warnings(places, today)
    L = ["# Local Places Directory - Executive Summary", "",
         f"_Generated {s['generated_on']}_", "", "## Key figures", "",
         f"- Total places: **{s['total']}**",
         f"- Average rating: **{s['avg_rating']}** / 5",
         f"- Average distance: **{s['avg_distance_km']} km**",
         f"- Average price level: **{s['avg_price_level']}** / 4",
         f"- Stale records (>180 days): **{s['stale_count']}**", "",
         "## By category", "",
         "| Category | Count | Avg rating | Avg distance (km) |", "|---|---:|---:|---:|"]
    for c, v in s["categories"].items():
        L.append(f"| {c} | {v['count']} | {v['avg_rating']} | {v['avg_distance_km']} |")
    L += ["", "## Status", ""] + [f"- {k.replace('_', ' ')}: {v}" for k, v in s["status_counts"].items()]
    L += ["", "## Trends", ""] + [f"- {t}" for t in s["trends"]]
    L += ["", "## Top rated", ""] + [f"1. {n}" for n in s["top_rated"]]
    L += ["", f"## Warnings ({len(w)})", ""]
    L += [f"- **{x['level']}** #{x['id']} {x['name']}: {x['message']}" for x in w] or ["- None"]
    return "\n".join(L) + "\n"


def render_audit_log(places, today=None) -> str:
    stamp = datetime.now().isoformat(timespec="seconds")
    lines = [f"[{stamp}] AUDIT START records={len(places)}"]
    for x in find_warnings(places, today):
        lines.append(f"[{stamp}] {x['level']:<8} id={x['id']:<4} {x['name']} :: {x['message']}")
    lines.append(f"[{stamp}] AUDIT END")
    return "\n".join(lines) + "\n"


def render_summary_csv(places, today=None) -> str:
    s = summarize(places, today)
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\n")
    w.writerow(["category", "count", "avg_rating", "avg_distance_km"])
    for c, v in s["categories"].items():
        w.writerow([c, v["count"], v["avg_rating"], v["avg_distance_km"]])
    return buf.getvalue()


def export_all(places, out_dir, today=None) -> list:
    out = Path(out_dir)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    files = {
        f"summary-{stamp}.md": render_markdown(places, today),
        f"audit-{stamp}.log": render_audit_log(places, today),
        f"summary-{stamp}.csv": render_summary_csv(places, today),
        f"places-{stamp}.csv": places_to_csv(places),
    }
    paths = []
    for name, text in files.items():
        atomic_write_text(out / name, text)
        paths.append(out / name)
    return paths
