"""Interactive terminal menu + argparse sub-commands."""
from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

from . import __version__
from .analytics import find_warnings, summarize
from .charts import ascii_bars, save_png
from .export import export_all
from .importer import import_csv
from .models import CATEGORIES, STATUSES
from .search import SORTS, search
from .storage import PlaceStore
from .validation import (ValidationError, v_address, v_category, v_date, v_distance,
                         v_hours, v_name, v_phone, v_price, v_rating, v_status, v_tags)

ROOT = Path(__file__).resolve().parent.parent
DEFAULT_DATA = ROOT / "data" / "places.json"
EXPORT_DIR = ROOT / "exports"

if os.name == "nt":  # enable ANSI escape handling in classic Windows consoles
    os.system("")
_COLOR = sys.stdout.isatty() and not os.environ.get("NO_COLOR")


def _c(code: str, text: str) -> str:
    return f"\033[{code}m{text}\033[0m" if _COLOR else text


def bold(t): return _c("1", t)
def red(t): return _c("31", t)
def green(t): return _c("32", t)
def yellow(t): return _c("33", t)
def cyan(t): return _c("36", t)
def dim(t): return _c("2", t)


BANNER = r"""
  _                    _   ____  _                     ____  _               _
 | |    ___   ___ __ _| | |  _ \| | __ _  ___ ___ ___|  _ \(_)_ __ ___  ___| |_ ___  _ __ _   _
 | |   / _ \ / __/ _` | | | |_) | |/ _` |/ __/ _ Y __| | | | | '__/ _ \/ __| __/ _ \| '__| | | |
 | |__| (_) | (_| (_| | | |  __/| | (_| | (_|  __|__ \ |_| | | | |  __/ (__| || (_) | |  | |_| |
 |_____\___/ \___\__,_|_| |_|   |_|\__,_|\___\___|___/____/|_|_|  \___|\___|\__\___/|_|   \__, |
                                                                                          |___/
"""


# ---------------------------------------------------------------- input wrappers
def ask(prompt: str, validator, default=None, optional: bool = False):
    """Loop until the validator accepts the input. Never crashes on bad input."""
    while True:
        shown = f"{prompt} [{default}]: " if default not in (None, "") else f"{prompt}: "
        raw = input(shown).strip()
        if raw == "" and default is not None:
            raw = str(default)
        if raw == "" and optional:
            return validator("")
        try:
            return validator(raw)
        except ValidationError as exc:
            print(red(f"  x {exc}"))


def ask_int(prompt: str, lo: int, hi: int) -> int:
    def check(raw):
        try:
            n = int(raw)
        except ValueError:
            raise ValidationError("Enter a whole number") from None
        if not lo <= n <= hi:
            raise ValidationError(f"Enter a number between {lo} and {hi}")
        return n
    return ask(prompt, check)


def confirm(prompt: str) -> bool:
    while True:
        a = input(f"{prompt} (y/n): ").strip().lower()
        if a in ("y", "yes"):
            return True
        if a in ("n", "no"):
            return False
        print(red("  x Please answer y or n"))


# ---------------------------------------------------------------- presentation
def _fit(text, width):
    text = str(text)
    return text if len(text) <= width else text[: width - 1] + "~"


def render_table(places) -> str:
    cols = [("ID", 4), ("Name", 30), ("Category", 11), ("Rate", 5), ("Km", 6), ("$", 2), ("Status", 10)]
    head = " | ".join(f"{n:<{w}}" for n, w in cols)
    rows = [head, "-+-".join("-" * w for _, w in cols)]
    for p in places:
        vals = [p.id, p.name, p.category, f"{p.rating:.1f}", f"{p.distance_km:.1f}",
                p.price_level, p.status.replace("_", " ")]
        rows.append(" | ".join(f"{_fit(v, w):<{w}}" for v, (_, w) in zip(vals, cols)))
    return "\n".join(rows)


def show_table(places, page_size: int = 10) -> None:
    if not places:
        print(yellow("No places found."))
        return
    for start in range(0, len(places), page_size):
        chunk = places[start:start + page_size]
        print(render_table(chunk) if start == 0 else "\n".join(render_table(chunk).split("\n")[2:]))
        end = start + len(chunk)
        if end < len(places):
            if input(dim(f"-- {end}/{len(places)} shown. Enter = next page, q = stop -- ")).strip().lower() == "q":
                break
    print(dim(f"{len(places)} result(s)"))


def show_detail(p) -> None:
    print(bold(f"\n#{p.id}  {p.name}"))
    for label, val in (("Category", p.category), ("Address", p.address), ("Rating", f"{p.rating}/5"),
                       ("Distance", f"{p.distance_km} km"), ("Price level", "$" * p.price_level),
                       ("Status", p.status), ("Phone", p.phone or "-"), ("Hours", p.hours or "-"),
                       ("Tags", ", ".join(p.tags) or "-"), ("Verified", p.last_verified)):
        print(f"  {label:<12}{val}")


def show_summary(places) -> None:
    s = summarize(places)
    print(bold("\n=== EXECUTIVE SUMMARY ==="))
    print(f"Total places      : {s['total']}")
    print(f"Average rating    : {s['avg_rating']} / 5")
    print(f"Average distance  : {s['avg_distance_km']} km")
    print(f"Average price lvl : {s['avg_price_level']} / 4")
    print(f"Stale (>180 days) : {s['stale_count']}")
    print(bold("\nStatus indicators"))
    for k, v in s["status_counts"].items():
        mark = green("*") if k == "open" else yellow("*")
        print(f"  {mark} {k.replace('_', ' '):<20}{v}")
    print(bold("\nBy category"))
    print(f"  {'Category':<12}{'Count':>6}{'Avg rating':>12}{'Avg km':>9}")
    for c, v in s["categories"].items():
        print(f"  {c:<12}{v['count']:>6}{v['avg_rating']:>12}{v['avg_distance_km']:>9}")
    print(bold("\nKey trends"))
    for t in s["trends"]:
        print(f"  - {t}")
    print(bold("\nTop rated: ") + ", ".join(s["top_rated"]))
    print(bold("Nearest  : ") + ", ".join(s["nearest"]))


def show_warnings(places) -> None:
    ws = find_warnings(places)
    print(bold(f"\n=== THRESHOLD WARNINGS ({len(ws)}) ==="))
    colour = {"CRITICAL": red, "WARNING": yellow, "INFO": cyan}
    for w in ws:
        tag = colour[w["level"]]("[" + w["level"] + "]")
        pad = " " * max(0, 11 - len(w["level"]) - 2)
        print(f"{tag}{pad} #{w['id']:<3} {_fit(w['name'], 30):<30} {w['message']}")
    if not ws:
        print(green("All clear."))


def show_charts(places, export_png: bool = True) -> None:
    s = summarize(places)
    print(bold("\nPlaces per category"))
    print(ascii_bars({c: v["count"] for c, v in s["categories"].items()}))
    print(bold("\nAverage rating per category (max 5)"))
    print(ascii_bars({c: v["avg_rating"] for c, v in s["categories"].items()}, max_value=5))
    print(bold("\nRating distribution"))
    print(ascii_bars(s["rating_distribution"]))
    if export_png:
        png = save_png(s, EXPORT_DIR / "charts.png")
        print(dim(f"\nPNG chart saved to {png}" if png else "\n(Install matplotlib to also save a PNG chart.)"))


# ---------------------------------------------------------------- menu actions
def _v_sort(raw: str) -> str:
    s = raw.strip().lower()
    if s not in SORTS:
        raise ValidationError("Choose one of: " + ", ".join(SORTS))
    return s


def action_search(store) -> None:
    kw = input("Keyword (blank = any): ").strip()
    print(f"Categories: {', '.join(CATEGORIES)}")
    cat = ask("Category (blank = any)", lambda r: v_category(r) if r else None, optional=True)
    minr = ask("Minimum rating 0-5 (blank = any)", lambda r: v_rating(r) if r else None, optional=True)
    maxd = ask("Max distance km (blank = any)", lambda r: v_distance(r) if r else None, optional=True)
    sort = ask(f"Sort by {'/'.join(SORTS)}", _v_sort, default="relevance")
    show_table(search(store.places, kw, cat, minr, maxd, sort=sort))


def action_add(store) -> None:
    print(bold("\nAdd a new place") + dim("  (Enter on optional fields to skip)"))
    raw = {
        "name": ask("Name", v_name),
        "category": ask(f"Category ({', '.join(CATEGORIES)})", v_category),
        "address": ask("Address", v_address),
        "rating": ask("Rating 0-5", v_rating),
        "distance_km": ask("Distance from campus (km, 0-50)", v_distance),
        "price_level": ask("Price level 1-4", v_price),
        "status": ask(f"Status ({'/'.join(STATUSES)})", v_status, default="open"),
        "phone": ask("Phone", v_phone, optional=True),
        "hours": ask("Hours (09:00-21:00 or 24x7)", v_hours, optional=True),
        "tags": ask("Tags (comma separated)", v_tags, optional=True),
        "last_verified": ask("Last verified YYYY-MM-DD", v_date, optional=True),
    }
    place, errs = store.add_raw(raw)
    if errs:
        print(red("  x " + "; ".join(errs)))
    else:
        print(green(f"Saved as #{place.id}."))


def action_edit(store) -> None:
    pid = ask_int("ID to edit", 1, 10**9)
    p = store.get(pid)
    if not p:
        print(red("  x No such ID"))
        return
    show_detail(p)
    print(dim("Press Enter to keep the current value."))
    changes = {
        "name": ask("Name", v_name, default=p.name),
        "category": ask("Category", v_category, default=p.category),
        "address": ask("Address", v_address, default=p.address),
        "rating": ask("Rating", v_rating, default=p.rating),
        "distance_km": ask("Distance km", v_distance, default=p.distance_km),
        "price_level": ask("Price level", v_price, default=p.price_level),
        "status": ask("Status", v_status, default=p.status),
        "last_verified": ask("Last verified", v_date, default=p.last_verified),
    }
    _, errs = store.update_raw(pid, changes)
    print(red("  x " + "; ".join(errs)) if errs else green("Updated."))


def action_delete(store) -> None:
    pid = ask_int("ID to delete", 1, 10**9)
    p = store.get(pid)
    if not p:
        print(red("  x No such ID"))
    elif confirm(f"Delete '{p.name}'?"):
        store.delete(pid)
        print(green("Deleted."))


def action_export(store) -> None:
    for path in export_all(store.places, EXPORT_DIR):
        print(green("  wrote ") + str(path))


def action_import(store) -> None:
    path = input("Path to CSV file: ").strip().strip('"')
    report_import(import_csv(store, path, EXPORT_DIR))


def report_import(res) -> None:
    if res.fatal:
        print(red("  x " + res.fatal))
        return
    print(f"Rows read: {res.total_rows}   Added: {green(str(res.added))}   Rejected: {red(str(len(res.errors)))}")
    for n, msg in res.errors[:10]:
        print(f"  row {n}: {msg}")
    if len(res.errors) > 10:
        print(dim(f"  ... {len(res.errors) - 10} more in the log"))
    if res.log_path:
        print(dim(f"Full error log: {res.log_path}"))


MENU = (
    ("1", "Browse all places", lambda s: show_table(sorted(s.places, key=lambda p: p.name.lower()))),
    ("2", "Search (keyword / category / rating / distance)", action_search),
    ("3", "View place details", lambda s: (lambda p: show_detail(p) if p else print(red("  x No such ID")))(
        s.get(ask_int("ID", 1, 10**9)))),
    ("4", "Add a place", action_add),
    ("5", "Edit a place", action_edit),
    ("6", "Delete a place", action_delete),
    ("7", "Executive summary", lambda s: show_summary(s.places)),
    ("8", "Threshold warnings", lambda s: show_warnings(s.places)),
    ("9", "Charts", lambda s: show_charts(s.places)),
    ("10", "Export reports (Markdown / audit log / CSV)", action_export),
    ("11", "Bulk import from CSV", action_import),
)


def run_menu(store: PlaceStore) -> None:
    print(cyan(BANNER))
    print(bold(f"Local Places Directory v{__version__}") + dim("  - find useful places near campus"))
    for note in store.notices:
        print(yellow("! " + note))
    ws = find_warnings(store.places)
    crit = sum(1 for w in ws if w["level"] != "INFO")
    print(f"{len(store.places)} places loaded." + (yellow(f"  {crit} warning(s) - see option 8.") if crit else ""))
    actions = {k: fn for k, _, fn in MENU}
    while True:
        print(bold("\n--- MENU ---"))
        for k, label, _ in MENU:
            print(f"  {k:>2}. {label}")
        print("   0. Exit")
        choice = input("Choose an option: ").strip()
        if choice == "0":
            print("Goodbye! All changes are already saved.")
            return
        fn = actions.get(choice)
        if fn is None:
            print(red("  x Invalid choice. Enter a number from the menu."))
            continue
        try:
            fn(store)
        except (EOFError, KeyboardInterrupt):
            raise
        except OSError as exc:
            print(red(f"  x File error: {exc}"))


# ---------------------------------------------------------------- entry point
def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="lpd", description="Local Places Directory")
    p.add_argument("--data", default=str(DEFAULT_DATA), help="path to places.json")
    sub = p.add_subparsers(dest="cmd")
    s = sub.add_parser("search", help="search the directory")
    s.add_argument("keyword", nargs="*")
    s.add_argument("--category")
    s.add_argument("--min-rating", type=float)
    s.add_argument("--max-distance", type=float)
    s.add_argument("--sort", default="relevance", choices=SORTS)
    sub.add_parser("summary", help="executive summary")
    sub.add_parser("warnings", help="threshold warnings")
    sub.add_parser("export", help="write Markdown / audit log / CSV reports")
    i = sub.add_parser("import", help="bulk import a CSV file")
    i.add_argument("file")
    w = sub.add_parser("web", help="start the website")
    w.add_argument("--port", type=int, default=8000)
    w.add_argument("--host", default="127.0.0.1")
    w.add_argument("--no-browser", action="store_true")
    return p


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    for stream in (sys.stdout, sys.stderr):  # unicode-safe output on Windows consoles
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, ValueError):
            pass
    store = PlaceStore(args.data).load()
    try:
        if args.cmd is None:
            run_menu(store)
        elif args.cmd == "search":
            cat = None
            if args.category:
                try:
                    cat = v_category(args.category)
                except ValidationError as exc:
                    print(red(str(exc)))
                    return 2
            show_table(search(store.places, " ".join(args.keyword), cat, args.min_rating,
                              args.max_distance, sort=args.sort), page_size=10**6)
        elif args.cmd == "summary":
            show_summary(store.places)
        elif args.cmd == "warnings":
            show_warnings(store.places)
        elif args.cmd == "export":
            for path in export_all(store.places, EXPORT_DIR):
                print("wrote", path)
        elif args.cmd == "import":
            res = import_csv(store, args.file, EXPORT_DIR)
            report_import(res)
            return 1 if res.fatal else 0
        elif args.cmd == "web":
            from .web import serve
            serve(store, args.host, args.port, open_browser=not args.no_browser)
    except (EOFError, KeyboardInterrupt):
        print("\nInterrupted. Data is saved after every change - nothing was lost.")
    return 0
