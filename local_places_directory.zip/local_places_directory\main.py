#!/usr/bin/env python3
"""Local Places Directory - entry point.

    python main.py                 interactive terminal menu
    python main.py web             start the website at http://127.0.0.1:8000
    python main.py search cafe --min-rating 4
    python main.py summary | warnings | export | import FILE.csv
"""
import sys

from lpd.cli import main

if __name__ == "__main__":
    sys.exit(main())
