"""Executive summary (totals, averages, status indicators, trends) and threshold warnings."""
from __future__ import annotations

from collections import Counter, defaultdict
from datetime import date

STALE_DAYS = 180
LOW_RATING = 2.5
FAR_KM = 25.0


def _avg(values) -> float:
    values = list(values)
    return round(sum(values) / len(values), 2) if values else 0.0


def _age_days(place, today: date) -> int:
    try:
        return (today - date.fromisoformat(place.last_verified)).days
    except ValueError:
        return 10**6


def summarize(places, today: date | None = None) -> dict:
    today = today or date.today()
    n = len(places)
    by_cat = defaultdict(list)
    for p in places:
        by_cat[p.category].append(p)
    categories = {
        c: {
            "count": len(ps),
            "avg_rating": _avg(p.rating for p in ps),
            "avg_distance_km": _avg(p.distance_km for p in ps),
        }
        for c, ps in sorted(by_cat.items())
    }
    status = Counter(p.status for p in places)
    ranked = sorted(places, key=lambda p: (-p.rating, p.distance_km))
    nearest = sorted(places, key=lambda p: (p.distance_km, -p.rating))
    buckets = {"0-1.9": 0, "2-2.9": 0, "3-3.9": 0, "4-5": 0}
    for p in places:
        key = "0-1.9" if p.rating < 2 else "2-2.9" if p.rating < 3 else "3-3.9" if p.rating < 4 else "4-5"
        buckets[key] += 1
    qualified = {c: v for c, v in categories.items() if v["count"] >= 2}
    best_cat = max(qualified, key=lambda c: qualified[c]["avg_rating"]) if qualified else None
    closest_cat = min(categories, key=lambda c: categories[c]["avg_distance_km"]) if categories else None
    fresh = sum(1 for p in places if _age_days(p, today) <= 90)
    trends = []
    if best_cat:
        trends.append(f"{best_cat} is the best-rated category (avg {qualified[best_cat]['avg_rating']}).")
    if closest_cat:
        trends.append(f"{closest_cat} places are the closest on average ({categories[closest_cat]['avg_distance_km']} km).")
    if n:
        trends.append(f"{round(100 * fresh / n)}% of records were verified in the last 90 days.")
        trends.append(f"{round(100 * status.get('open', 0) / n)}% of places are currently open.")
    return {
        "generated_on": today.isoformat(),
        "total": n,
        "avg_rating": _avg(p.rating for p in places),
        "avg_distance_km": _avg(p.distance_km for p in places),
        "avg_price_level": _avg(p.price_level for p in places),
        "status_counts": dict(status),
        "categories": categories,
        "rating_distribution": buckets,
        "price_distribution": dict(sorted(Counter(p.price_level for p in places).items())),
        "top_rated": [p.name for p in ranked[:5]],
        "nearest": [p.name for p in nearest[:5]],
        "stale_count": sum(1 for p in places if _age_days(p, today) > STALE_DAYS),
        "trends": trends,
    }


def find_warnings(places, today: date | None = None) -> list:
    """Threshold indicators: CRITICAL / WARNING / INFO, each with a place id."""
    today = today or date.today()
    out = []
    seen = {}
    for p in places:
        key = (p.name.lower(), p.address.lower())
        if key in seen:
            out.append({"level": "CRITICAL", "id": p.id, "name": p.name,
                        "message": f"Duplicate of record #{seen[key]}"})
        seen.setdefault(key, p.id)
        age = _age_days(p, today)
        if age > STALE_DAYS:
            out.append({"level": "WARNING", "id": p.id, "name": p.name,
                        "message": f"Not verified for {age} days (limit {STALE_DAYS})"})
        if p.rating < LOW_RATING:
            out.append({"level": "WARNING", "id": p.id, "name": p.name,
                        "message": f"Low rating {p.rating} (< {LOW_RATING})"})
        if p.distance_km > FAR_KM:
            out.append({"level": "WARNING", "id": p.id, "name": p.name,
                        "message": f"Unusually far: {p.distance_km} km (> {FAR_KM} km)"})
        if p.status != "open":
            out.append({"level": "INFO", "id": p.id, "name": p.name,
                        "message": f"Status is {p.status.replace('_', ' ')}"})
    order = {"CRITICAL": 0, "WARNING": 1, "INFO": 2}
    out.sort(key=lambda w: (order[w["level"]], w["id"]))
    return out
