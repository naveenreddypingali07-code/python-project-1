"""Data model for a directory record."""
from __future__ import annotations

from dataclasses import asdict, dataclass, field

CATEGORIES = (
    "Food", "Cafe", "Healthcare", "Pharmacy", "Bank/ATM", "Transport",
    "Education", "Shopping", "Fuel", "Recreation", "Worship", "Services",
)
STATUSES = ("open", "closed", "temporarily_closed")
FIELDS = (
    "id", "name", "category", "address", "rating", "distance_km",
    "price_level", "status", "phone", "hours", "tags", "last_verified",
)


@dataclass
class Place:
    id: int
    name: str
    category: str
    address: str
    rating: float
    distance_km: float
    price_level: int
    status: str = "open"
    phone: str = ""
    hours: str = ""
    tags: list = field(default_factory=list)
    last_verified: str = ""

    def to_dict(self) -> dict:
        return asdict(self)

    def to_csv_row(self) -> dict:
        row = self.to_dict()
        row["tags"] = ";".join(self.tags)
        return row

    @classmethod
    def from_dict(cls, data: dict) -> "Place":
        return cls(**{k: data[k] for k in FIELDS if k in data})
