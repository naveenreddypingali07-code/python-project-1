"""Bulk CSV import with header check and row-by-row error log."""
from __future__ import annotations

import csv
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

from .storage import PlaceStore, atomic_write_text
from .validation import REQUIRED


@dataclass
class ImportResult:
    total_rows: int = 0
    added: int = 0
    errors: list = field(default_factory=list)  # (row_number, message)
    fatal: str = ""
    log_path: Path | None = None


def import_csv(store: PlaceStore, csv_path, log_dir=None) -> ImportResult:
    res = ImportResult()
    try:
        with open(csv_path, newline="", encoding="utf-8-sig") as fh:
            reader = csv.DictReader(fh)
            headers = {(h or "").strip().lower() for h in (reader.fieldnames or [])}
            missing = [k for k in REQUIRED if k not in headers]
            if missing:
                res.fatal = "Missing required column(s): " + ", ".join(missing)
                return res
            for row_no, row in enumerate(reader, start=2):  # header is row 1
                res.total_rows += 1
                norm = {(k or "").strip().lower(): v for k, v in row.items() if k}
                if None in row:
                    res.errors.append((row_no, "too many columns in row"))
                    continue
                place, errs = store.add_raw(norm, persist=False)
                if errs:
                    res.errors.append((row_no, "; ".join(errs)))
                else:
                    res.added += 1
    except FileNotFoundError:
        res.fatal = f"File not found: {csv_path}"
        return res
    except (UnicodeDecodeError, csv.Error) as exc:
        res.fatal = f"Could not read CSV: {exc}"
        return res
    if res.added:
        store.save()
    if res.errors and log_dir is not None:
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        lines = [f"Import of {csv_path} at {stamp}",
                 f"rows={res.total_rows} added={res.added} rejected={len(res.errors)}", ""]
        lines += [f"row {n}: {msg}" for n, msg in res.errors]
        res.log_path = Path(log_dir) / f"import-errors-{stamp}.log"
        atomic_write_text(res.log_path, "\n".join(lines) + "\n")
    return res
