# Architecture

```
            +-------------+      +-------------+
            |  CLI (menu) |      | Web (HTTP)  |      presentation layer
            +------+------+      +------+------+
                   |                    |
        +----------+--------------------+-----------+
        |  validation  |  search  |  analytics  |  export  |  importer  |   business logic
        +----------------------+--------------------+
                               |
                        PlaceStore  (CRUD, duplicate rules)
                               |
                  atomic_write_text  ->  data/places.json / *.csv     persistence
```

Design decisions
- **Standard library only** - runs anywhere with Python 3.10+, no install step for the demo.
- **Dataclass model** (`Place`) with a single `FIELDS` schema shared by JSON and CSV.
- **One validator** (`validate_record`) is the only way a record enters the system.
- **Atomic writes**: temp file in the same folder -> `flush` -> `fsync` -> `os.replace`.
- **Recovery**: missing file -> clean template; invalid JSON / wrong structure -> timestamped backup + reset;
  invalid individual records -> skipped with a notice, rest preserved.
- **Search**: tokenised AND-match over name/tags/category/address with weighted relevance
  (name-prefix > name > tag = category > address), then filters and sort.
- **Warnings** have levels (CRITICAL / WARNING / INFO) and thresholds as module constants
  (`STALE_DAYS`, `LOW_RATING`, `FAR_KM`) - easy to tune.
- **Security**: input sanitisation, size-limited JSON bodies, `textContent` rendering,
  CSP + nosniff + frame-deny headers, localhost binding. Auth is out of scope per the brief.

Extending: add a field in `models.FIELDS` + a validator in `validation.py`; both UIs, import and export pick it up.
