import unittest
from datetime import date

from lpd.analytics import find_warnings, summarize
from lpd.charts import ascii_bars
from lpd.export import render_audit_log, render_markdown, render_summary_csv
from lpd.models import Place
from lpd.search import search

TODAY = date(2026, 11, 25)


def P(i, name, cat="Food", rating=4.0, km=1.0, price=1, status="open", tags=(), verified="2026-11-01", addr=None):
    return Place(i, name, cat, addr or f"{i} Street", rating, km, price, status, "", "", list(tags), verified)


DATA = [
    P(1, "Biryani House", "Food", 4.4, 0.8, 2, tags=["biryani", "family"]),
    P(2, "Chai Corner", "Cafe", 4.5, 0.2, 1, tags=["chai", "budget"]),
    P(3, "Budget Mess", "Food", 3.0, 1.2, 1, tags=["budget", "veg"]),
    P(4, "Old Clinic", "Healthcare", 2.0, 30.0, 3, status="closed", verified="2025-01-01"),
    P(5, "Chai Corner", "Cafe", 4.0, 2.0, 1, addr="1 Street"),  # duplicate name+address of #1? no: different name -> not dup
]


class SearchTests(unittest.TestCase):
    def test_keyword_matches_name_tag_address(self):
        self.assertEqual([p.id for p in search(DATA, "biryani")], [1])
        self.assertEqual({p.id for p in search(DATA, "budget")}, {2, 3})
        self.assertEqual({p.id for p in search(DATA, "street")}, {1, 2, 3, 4, 5})

    def test_and_semantics_and_case(self):
        self.assertEqual([p.id for p in search(DATA, "BUDGET veg")], [3])
        self.assertEqual(search(DATA, "nonexistent"), [])

    def test_name_prefix_ranks_first(self):
        ids = [p.id for p in search(DATA, "chai")]
        self.assertEqual(ids[0], 2)

    def test_filters(self):
        self.assertEqual({p.id for p in search(DATA, category="cafe")}, {2, 5})
        self.assertEqual({p.id for p in search(DATA, min_rating=4.4)}, {1, 2})
        self.assertEqual({p.id for p in search(DATA, max_distance=1.0)}, {1, 2})
        self.assertEqual({p.id for p in search(DATA, status="closed")}, {4})
        self.assertEqual({p.id for p in search(DATA, max_price=1)}, {2, 3, 5})

    def test_sorting_and_limit(self):
        self.assertEqual(search(DATA, sort="distance")[0].id, 2)
        self.assertEqual(search(DATA, sort="rating")[0].id, 2)
        self.assertEqual(len(search(DATA, limit=2)), 2)
        with self.assertRaises(ValueError):
            search(DATA, sort="bogus")

    def test_empty_directory(self):
        self.assertEqual(search([], "x"), [])


class AnalyticsTests(unittest.TestCase):
    def test_summary_numbers(self):
        s = summarize(DATA, TODAY)
        self.assertEqual(s["total"], 5)
        self.assertEqual(s["avg_rating"], round((4.4 + 4.5 + 3.0 + 2.0 + 4.0) / 5, 2))
        self.assertEqual(s["categories"]["Cafe"]["count"], 2)
        self.assertEqual(s["status_counts"], {"open": 4, "closed": 1})
        self.assertEqual(s["top_rated"][0], "Chai Corner")
        self.assertEqual(s["stale_count"], 1)

    def test_empty_summary_does_not_crash(self):
        s = summarize([], TODAY)
        self.assertEqual((s["total"], s["avg_rating"]), (0, 0.0))
        self.assertEqual(s["trends"], [])

    def test_warnings(self):
        w = find_warnings(DATA, TODAY)
        msgs = [x["message"] for x in w if x["id"] == 4]
        self.assertTrue(any("Not verified" in m for m in msgs))
        self.assertTrue(any("Low rating" in m for m in msgs))
        self.assertTrue(any("far" in m for m in msgs))
        self.assertTrue(any("closed" in m for m in msgs))
        self.assertEqual(w[0]["level"], "WARNING")

    def test_duplicate_is_critical(self):
        dup = DATA + [P(9, "Biryani House", addr="1 Street")]
        self.assertEqual(find_warnings(dup, TODAY)[0]["level"], "CRITICAL")


class ExportTests(unittest.TestCase):
    def test_markdown_audit_csv(self):
        md = render_markdown(DATA, TODAY)
        self.assertIn("| Cafe | 2 |", md)
        self.assertIn("## Warnings", md)
        self.assertIn("AUDIT START records=5", render_audit_log(DATA, TODAY))
        self.assertTrue(render_summary_csv(DATA, TODAY).startswith("category,count"))

    def test_ascii_bars(self):
        out = ascii_bars({"a": 2, "b": 4}, width=4)
        self.assertIn("####", out)
        self.assertEqual(ascii_bars({}), "(no data)")


if __name__ == "__main__":
    unittest.main()
