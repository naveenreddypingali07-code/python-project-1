"""Defensive input validation: one source of truth used by CLI, CSV import and web API."""
from __future__ import annotations

import math
import re
from datetime import date

from .models import CATEGORIES, STATUSES


class ValidationError(ValueError):
    """Raised when a single field value is invalid."""


_CTRL = re.compile(r"[\x00-\x1f\x7f]")
_PHONE = re.compile(r"^\+?\d[\d \-]{5,14}\d$")
_HOURS = re.compile(r"^([01]\d|2[0-3]):[0-5]\d-([01]\d|2[0-3]):[0-5]\d$")


def clean_text(raw) -> str:
    """Strip control characters, collapse whitespace."""
    if raw is None:
        return ""
    return re.sub(r"\s+", " ", _CTRL.sub(" ", str(raw))).strip()


def _text(label: str, lo: int, hi: int):
    def check(raw):
        s = clean_text(raw)
        if not lo <= len(s) <= hi:
            raise ValidationError(f"{label} must be {lo}-{hi} characters (got {len(s)})")
        return s
    return check


v_name = _text("Name", 2, 80)
v_address = _text("Address", 3, 120)


def v_category(raw) -> str:
    s = clean_text(raw).lower()
    for c in CATEGORIES:
        if c.lower() == s:
            return c
    raise ValidationError("Category must be one of: " + ", ".join(CATEGORIES))


def _number(raw, label: str) -> float:
    s = clean_text(raw)
    if not s:
        raise ValidationError(f"{label} is required")
    try:
        x = float(s)
    except ValueError:
        raise ValidationError(f"{label} must be a number (got '{s}')") from None
    if not math.isfinite(x):
        raise ValidationError(f"{label} must be a finite number")
    return x


def v_rating(raw) -> float:
    x = _number(raw, "Rating")
    if not 0 <= x <= 5:
        raise ValidationError("Rating must be between 0 and 5")
    return round(x, 1)


def v_distance(raw) -> float:
    x = _number(raw, "Distance")
    if not 0 <= x <= 50:
        raise ValidationError("Distance must be between 0 and 50 km")
    return round(x, 2)


def v_price(raw) -> int:
    x = _number(raw, "Price level")
    if x != int(x) or not 1 <= x <= 4:
        raise ValidationError("Price level must be a whole number 1-4")
    return int(x)


def v_status(raw) -> str:
    s = clean_text(raw).lower().replace(" ", "_")
    if not s:
        return "open"
    if s not in STATUSES:
        raise ValidationError("Status must be one of: " + ", ".join(STATUSES))
    return s


def v_phone(raw) -> str:
    s = clean_text(raw)
    if s and not _PHONE.match(s):
        raise ValidationError("Phone must be 7-16 digits (optional +, spaces, dashes)")
    return s


def v_hours(raw) -> str:
    s = clean_text(raw).lower()
    if not s:
        return ""
    if s == "24x7":
        return "24x7"
    if not _HOURS.match(s):
        raise ValidationError("Hours must look like 09:00-21:30 or 24x7")
    return s


def v_tags(raw) -> list:
    if raw is None:
        return []
    items = raw if isinstance(raw, (list, tuple)) else re.split(r"[;,]", str(raw))
    out = []
    for item in items:
        t = clean_text(item).lower()
        if not t:
            continue
        if len(t) > 20:
            raise ValidationError(f"Tag '{t[:20]}...' is longer than 20 characters")
        if t not in out:
            out.append(t)
    if len(out) > 8:
        raise ValidationError("At most 8 tags are allowed")
    return out


def v_date(raw, today: date | None = None) -> str:
    today = today or date.today()
    s = clean_text(raw)
    if not s:
        return today.isoformat()
    try:
        d = date.fromisoformat(s)
    except ValueError:
        raise ValidationError("Date must be YYYY-MM-DD") from None
    if d > today:
        raise ValidationError("Verification date cannot be in the future")
    if d.year < 2000:
        raise ValidationError("Verification date is unrealistically old")
    return d.isoformat()


REQUIRED = {
    "name": v_name, "category": v_category, "address": v_address,
    "rating": v_rating, "distance_km": v_distance, "price_level": v_price,
}


def validate_record(raw: dict, today: date | None = None):
    """Validate a whole record. Returns (clean_dict, errors). Never raises."""
    clean, errors = {}, []
    for key, fn in REQUIRED.items():
        try:
            clean[key] = fn(raw.get(key))
        except ValidationError as exc:
            errors.append(f"{key}: {exc}")
    optional = {
        "status": v_status, "phone": v_phone, "hours": v_hours, "tags": v_tags,
        "last_verified": lambda v: v_date(v, today),
    }
    for key, fn in optional.items():
        try:
            clean[key] = fn(raw.get(key))
        except ValidationError as exc:
            errors.append(f"{key}: {exc}")
    return (None if errors else clean), errors
