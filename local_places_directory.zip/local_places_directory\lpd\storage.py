"""Persistence: atomic JSON/CSV file I/O, corruption recovery, schema checks."""
from __future__ import annotations

import csv
import io
import json
import os
import shutil
import tempfile
from datetime import datetime
from pathlib import Path

from .models import FIELDS, Place
from .validation import validate_record

SCHEMA_VERSION = 1


def atomic_write_text(path, text: str) -> None:
    """Write to a temp file, fsync, then os.replace: never leaves a half-written file."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=path.name + ".", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as fh:
            fh.write(text)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp, path)
    except BaseException:
        if os.path.exists(tmp):
            os.unlink(tmp)
        raise


def places_to_csv(places) -> str:
    buf = io.StringIO()
    writer = csv.DictWriter(buf, fieldnames=list(FIELDS), lineterminator="\n")
    writer.writeheader()
    for p in places:
        writer.writerow(p.to_csv_row())
    return buf.getvalue()


class PlaceStore:
    """In-memory collection of places backed by a JSON file."""

    def __init__(self, path):
        self.path = Path(path)
        self.places: list[Place] = []
        self.notices: list[str] = []

    # ---------- load / save ----------
    def load(self) -> "PlaceStore":
        self.places, self.notices = [], []
        try:
            text = self.path.read_text(encoding="utf-8-sig")
            data = json.loads(text)
        except FileNotFoundError:
            self.notices.append(f"No data file found; created a clean one at {self.path}")
            self.save()
            return self
        except (json.JSONDecodeError, UnicodeDecodeError):
            self._quarantine("not valid JSON")
            return self
        records = data.get("places") if isinstance(data, dict) else data
        if not isinstance(records, list):
            self._quarantine("unexpected structure (expected a list of places)")
            return self
        used = set()
        for i, rec in enumerate(records, 1):
            if not isinstance(rec, dict):
                self.notices.append(f"Record #{i} skipped: not an object")
                continue
            clean, errors = validate_record(rec)
            if errors:
                self.notices.append(f"Record #{i} skipped: " + "; ".join(errors))
                continue
            pid = rec.get("id")
            if not isinstance(pid, int) or isinstance(pid, bool) or pid in used or pid < 1:
                pid = self._next_id(used)
            used.add(pid)
            self.places.append(Place(id=pid, **clean))
        return self

    def _quarantine(self, reason: str) -> None:
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        backup = self.path.with_name(f"{self.path.stem}.corrupt-{stamp}{self.path.suffix}")
        try:
            shutil.copy2(self.path, backup)
            self.notices.append(f"Data file was corrupted ({reason}); backed up to {backup.name} and reset.")
        except OSError:
            self.notices.append(f"Data file was corrupted ({reason}); reset to a clean template.")
        self.places = []
        self.save()

    def save(self) -> None:
        payload = {
            "schema_version": SCHEMA_VERSION,
            "saved_at": datetime.now().isoformat(timespec="seconds"),
            "places": [p.to_dict() for p in self.places],
        }
        atomic_write_text(self.path, json.dumps(payload, indent=2, ensure_ascii=False) + "\n")

    def save_csv(self, path) -> None:
        atomic_write_text(path, places_to_csv(self.places))

    # ---------- CRUD ----------
    @staticmethod
    def _next_id(used) -> int:
        return (max(used) + 1) if used else 1

    def next_id(self) -> int:
        return self._next_id({p.id for p in self.places})

    def get(self, pid: int):
        return next((p for p in self.places if p.id == pid), None)

    def is_duplicate(self, name: str, address: str, ignore_id=None) -> bool:
        key = (name.lower(), address.lower())
        return any(
            (p.name.lower(), p.address.lower()) == key and p.id != ignore_id
            for p in self.places
        )

    def add_raw(self, raw: dict, persist: bool = True):
        """Validate and add. Returns (place_or_None, errors)."""
        clean, errors = validate_record(raw)
        if errors:
            return None, errors
        if self.is_duplicate(clean["name"], clean["address"]):
            return None, ["duplicate: a place with this name and address already exists"]
        place = Place(id=self.next_id(), **clean)
        self.places.append(place)
        if persist:
            self.save()
        return place, []

    def update_raw(self, pid: int, changes: dict):
        place = self.get(pid)
        if place is None:
            return None, [f"id: no place with id {pid}"]
        merged = {**place.to_dict(), **changes}
        clean, errors = validate_record(merged)
        if errors:
            return None, errors
        if self.is_duplicate(clean["name"], clean["address"], ignore_id=pid):
            return None, ["duplicate: a place with this name and address already exists"]
        for k, v in clean.items():
            setattr(place, k, v)
        self.save()
        return place, []

    def delete(self, pid: int) -> bool:
        place = self.get(pid)
        if place is None:
            return False
        self.places.remove(place)
        self.save()
        return True
