# 5-minute demo script (matches "What a Good Demo Looks Like")

1. **Launch** - `python main.py`. Point out the branded banner and the numbered menu. Mention the
   warning count shown at start-up.
2. **Search** - menu `2`: keyword `biryani`, then `veg budget` (AND search), filter Category = Cafe,
   min rating 4, sort by distance.
3. **Defensive validation** - menu `4` (Add). Deliberately type: blank name, category `Spaceship`,
   rating `9`, rating `abc`, distance `-3`, phone `12`. Each is rejected with a clear message and re-prompted.
   Then enter valid values and show "Saved as #45".
4. **Analytics** - menu `7` (Executive summary): totals, averages, status indicators, trends. Menu `8`
   (warnings): stale records, low rating, 50 km outlier. Menu `9`: charts.
5. **Persistence** - menu `0` to exit, relaunch `python main.py`, search for the new place: it is still there.
   (Optional: corrupt `data/places.json` with a text editor, relaunch -> "backed up and reset" notice, no crash.)
6. **Bulk import** - menu `11` with `data/legacy_sample.csv`: 3 rows added, 7 rejected with row numbers; open the log in `exports/`.
7. **Export** - menu `10`, show the Markdown summary, audit log and CSVs in `exports/`.
8. **Website (bonus)** - `python main.py web`: live search, add form with server-side errors, Summary and Warnings tabs, download buttons.
9. **Tests** - `python -m unittest discover -s tests -t .` -> 48 tests OK.
