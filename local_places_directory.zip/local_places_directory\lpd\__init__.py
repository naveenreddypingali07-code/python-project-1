"""Local Places Directory (LPD) - search a curated JSON directory of nearby useful places."""

__version__ = "1.0.0"
