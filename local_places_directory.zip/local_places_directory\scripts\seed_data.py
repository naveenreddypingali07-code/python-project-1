﻿"""Generate the sample dataset (data/places.json + data/places.csv) and a messy legacy CSV.

Fictional-but-realistic places around a college campus. Contains normal rows, boundary values
(rating 0.0 / 5.0, distance 0 / 50 km), stale verification dates, closed places and unicode names.
Run:  python scripts/seed_data.py
"""
import csv
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from lpd.storage import PlaceStore  # noqa: E402

# name, category, address, rating, km, price, status, phone, hours, tags, verified
ROWS = [
    ("Campus Canteen", "Food", "Main Block Ground Floor", 3.8, 0.0, 1, "open", "", "08:00-18:00", "lunch;veg;budget", "2026-11-10"),
    ("Maisamma Biryani House", "Food", "Maisammaguda Main Road", 4.4, 0.8, 2, "open", "9876501001", "11:00-23:00", "biryani;non-veg;family", "2026-11-05"),
    ("Annapurna Mess", "Food", "Dhulapally Road", 4.1, 1.2, 1, "open", "9876501002", "07:00-21:30", "veg;tiffin;budget", "2026-10-28"),
    ("Spice Garden Restaurant", "Food", "Kompally Junction", 4.0, 3.6, 3, "open", "9876501003", "12:00-23:30", "family;north-indian;ac", "2026-09-14"),
    ("Midnight Dosa Point", "Food", "Gundlapochampally Cross", 4.2, 2.1, 1, "open", "", "18:00-23:59", "dosa;late-night;veg", "2026-10-02"),
    ("Chai Tapri Corner", "Cafe", "Opposite Main Gate", 4.5, 0.2, 1, "open", "", "06:00-22:00", "chai;snacks;budget", "2026-11-18"),
    ("Brew & Books Cafe", "Cafe", "Kompally Main Road", 4.3, 3.9, 3, "open", "9876501004", "10:00-22:00", "wifi;study;coffee", "2026-11-01"),
    ("The Daily Grind", "Cafe", "Suchitra Circle", 3.9, 5.2, 3, "open", "9876501005", "09:00-23:00", "coffee;wifi;dessert", "2026-08-20"),
    ("Frosty Scoops", "Cafe", "Dhulapally Road", 4.6, 1.5, 2, "temporarily_closed", "", "12:00-22:00", "ice-cream;dessert", "2026-10-15"),
    ("Sri Sai Clinic", "Healthcare", "Maisammaguda Village", 4.0, 0.9, 1, "open", "9876502001", "09:00-20:00", "doctor;general;clinic", "2026-11-12"),
    ("Medchal Government Hospital", "Healthcare", "Medchal Town", 3.2, 8.4, 1, "open", "04027000001", "24x7", "hospital;emergency;government", "2026-07-30"),
    ("Apollo Diagnostics Lab", "Healthcare", "Suchitra Circle", 4.4, 5.4, 3, "open", "9876502003", "07:00-20:00", "lab;tests;blood", "2026-10-09"),
    ("Dental Care Plus", "Healthcare", "Kompally Junction", 4.7, 3.7, 3, "open", "9876502004", "10:00-20:00", "dentist;clinic", "2026-11-03"),
    ("Eye Care Centre", "Healthcare", "Bowenpally", 3.6, 9.8, 2, "closed", "", "", "optician;eye", "2025-12-01"),
    ("MedPlus Pharmacy", "Pharmacy", "Maisammaguda Main Road", 4.2, 0.7, 2, "open", "9876503001", "08:00-23:00", "medicine;24h-delivery", "2026-11-08"),
    ("Jan Aushadhi Kendra", "Pharmacy", "Dhulapally Road", 4.0, 1.4, 1, "open", "", "09:00-21:00", "generic;budget;medicine", "2026-09-30"),
    ("Night Chemist 24x7", "Pharmacy", "Kompally Junction", 3.8, 3.5, 2, "open", "9876503003", "24x7", "emergency;medicine;late-night", "2026-10-21"),
    ("SBI ATM - Campus Gate", "Bank/ATM", "Opposite Main Gate", 3.5, 0.1, 1, "open", "", "24x7", "atm;cash;sbi", "2026-11-14"),
    ("HDFC Bank Branch", "Bank/ATM", "Kompally Main Road", 4.1, 3.8, 1, "open", "04044000111", "10:00-16:00", "bank;savings;loans", "2026-08-11"),
    ("Axis ATM Dhulapally", "Bank/ATM", "Dhulapally Road", 2.4, 1.3, 1, "temporarily_closed", "", "24x7", "atm;cash;axis", "2026-03-02"),
    ("Maisammaguda Bus Stop", "Transport", "Maisammaguda Main Road", 3.0, 0.3, 1, "open", "", "05:00-23:00", "bus;tsrtc;stop", "2026-10-05"),
    ("Metro Shuttle Pickup", "Transport", "Campus Parking", 4.3, 0.1, 1, "open", "9876504002", "06:30-20:30", "shuttle;metro;campus", "2026-11-16"),
    ("Quick Auto Stand", "Transport", "Dhulapally Cross", 3.7, 1.0, 2, "open", "", "05:30-23:30", "auto;rickshaw", "2026-09-01"),
    ("Secunderabad Railway Station", "Transport", "Secunderabad", 3.9, 18.5, 1, "open", "040-27821000", "24x7", "train;railway;long-distance", "2026-06-18"),
    ("Rajiv Gandhi International Airport", "Transport", "Shamshabad", 4.2, 50.0, 4, "open", "04066123000", "24x7", "airport;flights", "2026-05-02"),
    ("Print & Xerox Hub", "Services", "Opposite Main Gate", 4.4, 0.2, 1, "open", "9876505001", "08:00-20:00", "xerox;printing;spiral-binding", "2026-11-17"),
    ("Campus Stationery Mart", "Shopping", "Main Block Arcade", 4.0, 0.1, 1, "open", "", "09:00-18:00", "books;stationery;lab-records", "2026-11-11"),
    ("Reliance Smart Kompally", "Shopping", "Kompally Junction", 4.1, 3.7, 2, "open", "9876505003", "09:00-22:00", "grocery;supermarket", "2026-10-26"),
    ("Vijetha Supermarket", "Shopping", "Dhulapally Road", 3.7, 1.6, 1, "open", "", "07:00-22:30", "grocery;daily-needs", "2026-09-17"),
    ("Mobile Repair Studio", "Services", "Gundlapochampally Cross", 3.4, 2.3, 2, "open", "9876505005", "10:00-20:00", "mobile;repair;screen", "2026-04-04"),
    ("Laundry Express", "Services", "Maisammaguda Main Road", 3.9, 0.9, 1, "open", "9876505006", "08:00-20:00", "laundry;ironing", "2026-10-30"),
    ("Hair Studio & Salon", "Services", "Dhulapally Road", 4.2, 1.5, 2, "open", "9876505007", "10:00-21:00", "salon;haircut", "2026-10-12"),
    ("HP Petrol Pump", "Fuel", "Kompally Main Road", 4.0, 3.4, 2, "open", "9876506001", "24x7", "petrol;diesel;air", "2026-10-07"),
    ("Indian Oil Fuel Station", "Fuel", "Medchal Highway", 3.8, 6.1, 2, "open", "9876506002", "24x7", "petrol;diesel;ev-charging", "2026-08-25"),
    ("Central Library (Public)", "Education", "Medchal Town", 4.5, 7.9, 1, "open", "", "09:00-19:00", "library;reading;quiet", "2026-09-22"),
    ("Aakash Coaching Centre", "Education", "Kompally Junction", 3.9, 3.6, 3, "open", "9876507002", "08:00-20:00", "coaching;gate;exams", "2026-07-14"),
    ("Sunrise Sports Arena", "Recreation", "Dhulapally Road", 4.3, 1.8, 2, "open", "9876508001", "06:00-22:00", "cricket;football;turf", "2026-11-09"),
    ("PVR Cinemas Kompally", "Recreation", "Kompally Mall", 4.2, 4.0, 3, "open", "9876508002", "09:00-01:00", "movies;weekend", "2026-10-19"),
    ("Gaming Zone Arcade", "Recreation", "Suchitra Circle", 2.1, 5.3, 2, "closed", "", "", "games;arcade", "2025-06-12"),
    ("Sri Hanuman Temple", "Worship", "Maisammaguda Village", 4.7, 0.6, 1, "open", "", "05:30-20:30", "temple;peaceful", "2026-11-13"),
    ("Jama Masjid Dhulapally", "Worship", "Dhulapally Village", 4.6, 1.7, 1, "open", "", "04:30-22:00", "mosque;peaceful", "2026-10-11"),
    ("St. Mary's Church", "Worship", "Kompally Main Road", 4.5, 3.8, 1, "open", "", "06:00-19:00", "church;peaceful", "2026-09-07"),
    ("CafÃ© ZÃ¼rich Roasters", "Cafe", "Kompally Mall", 5.0, 4.1, 4, "open", "9876501009", "10:00-23:00", "coffee;premium;unicode", "2026-11-20"),
    ("Hostel Tiffin Service", "Food", "Boys Hostel Block", 0.0, 0.0, 1, "closed", "", "", "tiffin;hostel", "2025-01-15"),
]


def main():
    store = PlaceStore(ROOT / "data" / "places.json")
    store.places = []
    for row in ROWS:
        keys = ("name", "category", "address", "rating", "distance_km", "price_level",
                "status", "phone", "hours", "tags", "last_verified")
        place, errs = store.add_raw(dict(zip(keys, row)), persist=False)
        assert not errs, (row[0], errs)
    store.save()
    store.save_csv(ROOT / "data" / "places.csv")

    # legacy file with deliberate faults to demo bulk-import error logging
    legacy = ROOT / "data" / "legacy_sample.csv"
    header = ["name", "category", "address", "rating", "distance_km", "price_level", "status", "phone", "hours", "tags", "last_verified"]
    rows = [
        ["Campus Juice Bar", "Cafe", "Main Block Arcade", "4.2", "0.1", "1", "open", "", "09:00-17:00", "juice;healthy", "2026-11-01"],
        ["Green Leaf Salads", "Food", "Dhulapally Road", "4.0", "1.4", "2", "open", "9876509001", "11:00-21:00", "salad;healthy", "2026-10-20"],
        ["Bad Rating Place", "Food", "Somewhere Road", "9.5", "1.0", "2", "open", "", "", "", ""],
        ["", "Food", "No Name Street", "4.0", "1.0", "2", "open", "", "", "", ""],
        ["Wrong Category Shop", "Spaceship", "Mars Colony", "4.0", "1.0", "2", "open", "", "", "", ""],
        ["Text Distance Cafe", "Cafe", "Kompally Road", "4.0", "near", "2", "open", "", "", "", ""],
        ["Future Verified Store", "Shopping", "Kompally Road", "4.0", "2.0", "2", "open", "", "", "", "2099-01-01"],
        ["Campus Canteen", "Food", "Main Block Ground Floor", "3.8", "0.0", "1", "open", "", "", "", ""],
        ["Bad Hours Bakery", "Food", "Dhulapally Road", "4.1", "1.1", "2", "open", "", "9am-9pm", "bakery", ""],
        ["Tandoor Tales", "Food", "Kompally Junction", "4.3", "3.5", "3", "open", "9876509002", "12:00-23:00", "tandoori;family", "2026-11-02"],
    ]
    with open(legacy, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(header)
        w.writerows(rows)
    print(f"Seeded {len(store.places)} places; wrote data/places.json, places.csv, legacy_sample.csv")


if __name__ == "__main__":
    main()
