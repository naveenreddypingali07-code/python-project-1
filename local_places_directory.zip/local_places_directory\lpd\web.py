"""Website: a zero-dependency HTTP server exposing the same core as the CLI."""
from __future__ import annotations

import json
import re
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from .analytics import find_warnings, summarize
from .export import render_audit_log, render_markdown, render_summary_csv
from .models import CATEGORIES, STATUSES
from .search import SORTS, search
from .storage import PlaceStore, places_to_csv

STATIC = Path(__file__).parent / "static"
MAX_BODY = 20_000
SECURITY = {
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "Referrer-Policy": "no-referrer",
    "Content-Security-Policy": "default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'",
}


def make_server(store: PlaceStore, host="127.0.0.1", port=8000) -> ThreadingHTTPServer:
    lock = threading.Lock()

    class Handler(BaseHTTPRequestHandler):
        server_version = "LPD/1.0"

        def log_message(self, fmt, *args):  # quiet
            pass

        # ---- helpers
        def _send(self, status, body: bytes, ctype="application/json", extra=None):
            self.send_response(status)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            for k, v in {**SECURITY, **(extra or {})}.items():
                self.send_header(k, v)
            self.end_headers()
            self.wfile.write(body)

        def _json(self, obj, status=200):
            self._send(status, json.dumps(obj).encode("utf-8"), "application/json; charset=utf-8")

        def _body(self):
            try:
                length = int(self.headers.get("Content-Length", 0))
            except ValueError:
                return None
            if length <= 0 or length > MAX_BODY:
                return None
            try:
                data = json.loads(self.rfile.read(length).decode("utf-8"))
            except (ValueError, UnicodeDecodeError):
                return None
            return data if isinstance(data, dict) else None

        # ---- routes
        def do_GET(self):
            url = urlparse(self.path)
            q = {k: v[0] for k, v in parse_qs(url.query).items()}
            with lock:
                places = list(store.places)
            if url.path in ("/", "/index.html"):
                return self._send(200, (STATIC / "index.html").read_bytes(), "text/html; charset=utf-8")
            if url.path == "/api/meta":
                return self._json({"categories": CATEGORIES, "statuses": STATUSES, "sorts": SORTS})
            if url.path == "/api/places":
                try:
                    res = search(
                        places, q.get("q", ""), q.get("category") or None,
                        float(q["min_rating"]) if q.get("min_rating") else None,
                        float(q["max_distance"]) if q.get("max_distance") else None,
                        q.get("status") or None, sort=q.get("sort", "relevance"))
                except ValueError as exc:
                    return self._json({"errors": [str(exc)]}, 400)
                return self._json({"count": len(res), "places": [p.to_dict() for p in res]})
            if url.path == "/api/summary":
                return self._json(summarize(places))
            if url.path == "/api/warnings":
                return self._json(find_warnings(places))
            m = re.fullmatch(r"/api/export/(md|txt|csv|summary-csv)", url.path)
            if m:
                kind = m.group(1)
                text, ctype, name = {
                    "md": (render_markdown(places), "text/markdown", "summary.md"),
                    "txt": (render_audit_log(places), "text/plain", "audit.log"),
                    "csv": (places_to_csv(places), "text/csv", "places.csv"),
                    "summary-csv": (render_summary_csv(places), "text/csv", "summary.csv"),
                }[kind]
                return self._send(200, text.encode("utf-8"), ctype + "; charset=utf-8",
                                  {"Content-Disposition": f'attachment; filename="{name}"'})
            self._json({"errors": ["not found"]}, 404)

        def do_POST(self):
            if urlparse(self.path).path != "/api/places":
                return self._json({"errors": ["not found"]}, 404)
            data = self._body()
            if data is None:
                return self._json({"errors": ["body must be a JSON object under 20 KB"]}, 400)
            with lock:
                place, errs = store.add_raw(data)
            if errs:
                return self._json({"errors": errs}, 422)
            self._json(place.to_dict(), 201)

        def do_PUT(self):
            m = re.fullmatch(r"/api/places/(\d+)", urlparse(self.path).path)
            data = self._body()
            if not m or data is None:
                return self._json({"errors": ["bad request"]}, 400)
            data.pop("id", None)
            with lock:
                place, errs = store.update_raw(int(m.group(1)), data)
            if errs:
                return self._json({"errors": errs}, 404 if errs[0].startswith("id:") else 422)
            self._json(place.to_dict())

        def do_DELETE(self):
            m = re.fullmatch(r"/api/places/(\d+)", urlparse(self.path).path)
            if not m:
                return self._json({"errors": ["bad request"]}, 400)
            with lock:
                ok = store.delete(int(m.group(1)))
            self._json({"deleted": ok}, 200 if ok else 404)

    return ThreadingHTTPServer((host, port), Handler)


def serve(store: PlaceStore, host="127.0.0.1", port=8000, open_browser=True) -> None:
    server = make_server(store, host, port)
    url = f"http://{host}:{server.server_address[1]}/"
    print(f"Local Places Directory website running at {url}  (Ctrl+C to stop)")
    if open_browser:
        threading.Timer(0.6, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nServer stopped.")
    finally:
        server.server_close()
