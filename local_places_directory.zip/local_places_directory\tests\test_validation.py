import unittest
from datetime import date

from lpd.validation import (ValidationError, clean_text, v_category, v_date, v_distance, v_hours,
                            v_phone, v_price, v_rating, v_tags, validate_record)
from tests.helpers import good


class FieldTests(unittest.TestCase):
    def test_rating_boundaries(self):
        self.assertEqual(v_rating("0"), 0.0)
        self.assertEqual(v_rating("5"), 5.0)
        self.assertEqual(v_rating("4.26"), 4.3)
        for bad in ("-0.1", "5.1", "abc", "", "nan", "inf", None):
            with self.assertRaises(ValidationError, msg=bad):
                v_rating(bad)

    def test_distance_boundaries(self):
        self.assertEqual(v_distance("0"), 0.0)
        self.assertEqual(v_distance("50"), 50.0)
        for bad in ("50.01", "-1", "near", ""):
            with self.assertRaises(ValidationError):
                v_distance(bad)

    def test_price(self):
        self.assertEqual(v_price("3"), 3)
        for bad in ("0", "5", "2.5", "x", ""):
            with self.assertRaises(ValidationError):
                v_price(bad)

    def test_category_case_insensitive(self):
        self.assertEqual(v_category("  cAfE "), "Cafe")
        with self.assertRaises(ValidationError):
            v_category("Spaceship")

    def test_phone_hours(self):
        self.assertEqual(v_phone(""), "")
        self.assertEqual(v_phone("+91 98765-43210"), "+91 98765-43210")
        with self.assertRaises(ValidationError):
            v_phone("12ab")
        self.assertEqual(v_hours("24X7"), "24x7")
        self.assertEqual(v_hours("09:00-21:30"), "09:00-21:30")
        with self.assertRaises(ValidationError):
            v_hours("9am-9pm")
        with self.assertRaises(ValidationError):
            v_hours("25:00-26:00")

    def test_tags(self):
        self.assertEqual(v_tags("Wifi; wifi ,Coffee"), ["wifi", "coffee"])
        with self.assertRaises(ValidationError):
            v_tags("a;b;c;d;e;f;g;h;i")
        with self.assertRaises(ValidationError):
            v_tags("x" * 21)

    def test_date(self):
        today = date(2026, 11, 25)
        self.assertEqual(v_date("", today), "2026-11-25")
        self.assertEqual(v_date("2026-11-25", today), "2026-11-25")
        for bad in ("2026-11-26", "25/11/2026", "1999-01-01"):
            with self.assertRaises(ValidationError):
                v_date(bad, today)

    def test_clean_text_strips_control_chars(self):
        self.assertEqual(clean_text("  a\x00b\tc\n d  "), "a b c d")


class RecordTests(unittest.TestCase):
    def test_valid_record(self):
        clean, errs = validate_record(good())
        self.assertEqual(errs, [])
        self.assertEqual(clean["tags"], ["coffee", "wifi"])

    def test_all_errors_reported_together(self):
        clean, errs = validate_record(good(name="", rating="9", distance_km="x"))
        self.assertIsNone(clean)
        self.assertEqual(len(errs), 3)

    def test_missing_keys_do_not_crash(self):
        clean, errs = validate_record({})
        self.assertIsNone(clean)
        self.assertEqual(len(errs), 6)

    def test_html_is_kept_as_text_not_executed(self):
        clean, _ = validate_record(good(name="<b>Bold</b> Cafe"))
        self.assertEqual(clean["name"], "<b>Bold</b> Cafe")  # escaped at render time (web uses textContent)


if __name__ == "__main__":
    unittest.main()
