import json
import threading
import unittest
import urllib.error
import urllib.request
from contextlib import redirect_stdout
from io import StringIO
from pathlib import Path
from unittest.mock import patch

from lpd import cli
from lpd.importer import import_csv
from lpd.web import make_server
from tests.helpers import temp_store

HEADER = "name,category,address,rating,distance_km,price_level,status,phone,hours,tags,last_verified\n"


class ImporterTests(unittest.TestCase):
    def test_import_good_and_bad_rows(self):
        store, d = temp_store()
        f = d / "in.csv"
        f.write_text(HEADER
                     + "Alpha Cafe,Cafe,1 A Road,4.5,1.0,2,open,,,tea,2026-11-01\n"
                     + "Bad Rating,Food,2 B Road,9,1.0,2,,,,,\n"
                     + "Alpha Cafe,Cafe,1 A Road,4.5,1.0,2,open,,,,\n"
                     + "Beta Shop,Shopping,3 C Road,3.5,2.0,1,,,,,\n", encoding="utf-8")
        res = import_csv(store, f, d)
        self.assertEqual((res.total_rows, res.added, len(res.errors)), (4, 2, 2))
        self.assertEqual([n for n, _ in res.errors], [3, 4])  # spreadsheet row numbers
        self.assertTrue(res.log_path.exists())
        self.assertIn("row 3", res.log_path.read_text())
        self.assertEqual(len(store.places), 2)

    def test_missing_columns_and_file(self):
        store, d = temp_store()
        f = d / "bad.csv"
        f.write_text("name,category\nA,Cafe\n")
        self.assertIn("Missing required", import_csv(store, f, d).fatal)
        self.assertIn("not found", import_csv(store, d / "nope.csv", d).fatal)

    def test_bom_and_empty_file(self):
        store, d = temp_store()
        f = d / "bom.csv"
        f.write_bytes(b"\xef\xbb\xbf" + (HEADER + "Gamma,Food,9 Z Road,4,1,1,,,,,\n").encode())
        self.assertEqual(import_csv(store, f, d).added, 1)
        e = d / "empty.csv"
        e.write_text("")
        self.assertTrue(import_csv(store, e, d).fatal)

    def test_seed_legacy_sample(self):
        store, d = temp_store()
        legacy = Path(__file__).parent.parent / "data" / "legacy_sample.csv"
        if legacy.exists():
            res = import_csv(store, legacy, d)
            self.assertGreaterEqual(res.added, 3)
            self.assertGreaterEqual(len(res.errors), 5)


class CliTests(unittest.TestCase):
    def run_menu(self, store, inputs):
        out = StringIO()
        with patch("builtins.input", side_effect=inputs), redirect_stdout(out):
            cli.run_menu(store)
        return out.getvalue()

    def test_invalid_menu_choices_do_not_crash(self):
        store, _ = temp_store(3)
        out = self.run_menu(store, ["", "abc", "99", "-1", "0"])
        self.assertEqual(out.count("Invalid choice"), 4)

    def test_add_with_validation_retries(self):
        store, _ = temp_store()
        inputs = ["4",
                  "", "x", "Menu Test Cafe",           # name: blank, too short, ok
                  "Spaceship", "cafe",                  # category: bad, ok
                  "5 Main Rd",
                  "abc", "7", "4.5",                    # rating: text, out of range, ok
                  "-3", "1.2",                          # distance
                  "0", "9", "2",                        # price
                  "weird", "",                          # status -> default open
                  "12", "",                             # phone bad, then skip
                  "", "", "",                           # hours, tags, verified skip
                  "0"]
        out = self.run_menu(store, inputs)
        self.assertEqual(len(store.places), 1)
        self.assertEqual(store.places[0].rating, 4.5)
        self.assertGreaterEqual(out.count("  x "), 8)
        self.assertIn("Saved as #1", out)

    def test_delete_requires_confirmation(self):
        store, _ = temp_store(2)
        self.run_menu(store, ["6", "1", "maybe", "n", "0"])
        self.assertEqual(len(store.places), 2)
        self.run_menu(store, ["6", "1", "y", "0"])
        self.assertEqual(len(store.places), 1)

    def test_search_summary_warnings_paging(self):
        store, _ = temp_store(25)
        out = self.run_menu(store, ["1", "", "", "7", "8", "0"])
        self.assertIn("EXECUTIVE SUMMARY", out)
        self.assertIn("THRESHOLD WARNINGS", out)
        self.assertIn("25 result(s)", out)

    def test_argparse_search(self):
        store, d = temp_store(3)
        out = StringIO()
        with redirect_stdout(out):
            code = cli.main(["--data", str(d / "places.json"), "search", "place", "1"])
        self.assertEqual(code, 0)
        self.assertIn("Place 1", out.getvalue())


class WebTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.store, _ = temp_store(3)
        cls.server = make_server(cls.store, "127.0.0.1", 0)
        cls.base = f"http://127.0.0.1:{cls.server.server_address[1]}"
        threading.Thread(target=cls.server.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()

    def req(self, path, method="GET", body=None):
        data = json.dumps(body).encode() if body is not None else None
        r = urllib.request.Request(self.base + path, data=data, method=method,
                                   headers={"Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(r) as resp:
                return resp.status, resp.read().decode(), resp.headers
        except urllib.error.HTTPError as e:
            try:
                return e.code, e.read().decode(), e.headers
            finally:
                e.close()

    def test_index_and_headers(self):
        status, body, headers = self.req("/")
        self.assertEqual(status, 200)
        self.assertIn("Local Places Directory", body)
        self.assertEqual(headers["X-Content-Type-Options"], "nosniff")

    def test_search_api(self):
        status, body, _ = self.req("/api/places?q=place&sort=name")
        self.assertEqual(status, 200)
        self.assertEqual(json.loads(body)["count"], 3)
        self.assertEqual(self.req("/api/places?sort=bogus")[0], 400)
        self.assertEqual(self.req("/api/places?min_rating=abc")[0], 400)

    def test_create_validate_update_delete(self):
        good = {"name": "Web Cafe", "category": "Cafe", "address": "9 Web Road", "rating": 4, "distance_km": 2, "price_level": 2}
        status, body, _ = self.req("/api/places", "POST", good)
        self.assertEqual(status, 201)
        pid = json.loads(body)["id"]
        self.assertEqual(self.req("/api/places", "POST", good)[0], 422)            # duplicate
        self.assertEqual(self.req("/api/places", "POST", {**good, "rating": 99})[0], 422)
        self.assertEqual(self.req("/api/places", "POST", [1, 2])[0], 400)           # not an object
        self.assertEqual(self.req(f"/api/places/{pid}", "PUT", {"rating": 1})[0], 200)
        self.assertEqual(self.req("/api/places/99999", "PUT", {"rating": 1})[0], 404)
        self.assertEqual(self.req(f"/api/places/{pid}", "DELETE")[0], 200)
        self.assertEqual(self.req(f"/api/places/{pid}", "DELETE")[0], 404)

    def test_summary_warnings_exports(self):
        self.assertEqual(json.loads(self.req("/api/summary")[1])["total"] >= 3, True)
        self.assertIsInstance(json.loads(self.req("/api/warnings")[1]), list)
        for kind in ("md", "txt", "csv", "summary-csv"):
            status, body, headers = self.req(f"/api/export/{kind}")
            self.assertEqual(status, 200)
            self.assertIn("attachment", headers["Content-Disposition"])
        self.assertEqual(self.req("/nope")[0], 404)


if __name__ == "__main__":
    unittest.main()
