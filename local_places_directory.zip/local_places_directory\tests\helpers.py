import tempfile
from pathlib import Path

from lpd.storage import PlaceStore


def good(**over):
    base = {"name": "Test Cafe", "category": "Cafe", "address": "1 Test Road", "rating": "4.2",
            "distance_km": "1.5", "price_level": "2", "status": "open", "phone": "9876543210",
            "hours": "09:00-21:00", "tags": "coffee;wifi", "last_verified": "2026-11-01"}
    base.update(over)
    return base


def temp_store(n=0):
    d = Path(tempfile.mkdtemp())
    store = PlaceStore(d / "places.json").load()
    for i in range(n):
        store.add_raw(good(name=f"Place {i}", address=f"{i} Road"))
    return store, d
