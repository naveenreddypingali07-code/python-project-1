"""Terminal bar charts (zero-dependency) with optional Matplotlib PNG export."""
from __future__ import annotations

from pathlib import Path


def ascii_bars(data: dict, width: int = 30, max_value: float | None = None, fmt="{:g}") -> str:
    if not data:
        return "(no data)"
    top = max_value if max_value is not None else max(data.values()) or 1
    label_w = max(len(str(k)) for k in data)
    lines = []
    for k, v in data.items():
        n = int(round(width * v / top)) if top else 0
        lines.append(f"{str(k):<{label_w}} | {'#' * n:<{width}} {fmt.format(v)}")
    return "\n".join(lines)


def save_png(summary: dict, path) -> Path | None:
    """Save a category chart if matplotlib is installed; otherwise return None."""
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        return None
    cats = summary["categories"]
    fig, ax = plt.subplots(1, 2, figsize=(11, 4))
    ax[0].barh(list(cats), [v["count"] for v in cats.values()], color="#2563eb")
    ax[0].set_title("Places per category")
    ax[1].barh(list(cats), [v["avg_rating"] for v in cats.values()], color="#16a34a")
    ax[1].set_xlim(0, 5)
    ax[1].set_title("Average rating")
    fig.tight_layout()
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, dpi=120)
    plt.close(fig)
    return path
